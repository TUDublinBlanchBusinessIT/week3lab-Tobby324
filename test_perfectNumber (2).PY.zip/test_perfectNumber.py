#test_perfectNumber.py
from perfectNumber import perfectNumber

def test_perfect_number_8128():
    assert perfectNumber(8128) == True